package com.musict.budgetexpensemanagerhelp.modelclass

class ModeModel (var Mode : String)