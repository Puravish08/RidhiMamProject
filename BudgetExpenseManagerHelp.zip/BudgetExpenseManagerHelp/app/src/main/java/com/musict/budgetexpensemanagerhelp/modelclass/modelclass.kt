package com.musict.budgetexpensemanagerhelp.modelclass

data class modelclass (var category: String)


data class tieddata(var id:Int,var type : Int,var amount : String,var category: String , var date : String,var time : String,var mode : String , var note  :String)